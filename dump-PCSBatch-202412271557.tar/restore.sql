--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "PCSBatch";
--
-- Name: PCSBatch; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "PCSBatch" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


\connect "PCSBatch"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: callbatchroom(); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.callbatchroom()
    LANGUAGE plpgsql
    AS $$
declare sqlv varchar;
	   	countlink int := 0;
		resultv varchar;
		recidv int := 0;
	BEGIN
			/*
			sqlv := 'SELECT count(*) FROM pg_extension where extname = ''dblink'' ';

			execute sqlv into countlink;	
	
            if(coalesce(countlink,0::integer) = 0) then	
				create extension dblink;
			end if;
			*/
			SELECT dblink_connect('pcsbatch','host=192.168.1.215 port=5432 dbname=PCSJIM user=postgres password=postgres123 options=-csearch_path=') into resultv;
		
			sqlv := ' ''select * from public.sp_prosesbatchroom('''''''',NOW(),''''admin'''') '' ';
			--RAISE NOTICE 'sql = % ',sqlv ;
			sqlv := 'select * FROM dblink(''pcsbatch'', '|| sqlv ||')';
		    sqlv := sqlv || 'AS t(recid INTEGER); ';

		    --execute sqlv into recidv;	
		    
		    RAISE NOTICE 'sql = % ',sqlv ;
		    
			SELECT dblink_disconnect('pcsbatch') into resultv;         	  
			--DROP EXTENSION IF EXISTS dblink;					
		
	END;
$$;


--
-- Name: syswritelog(text); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.syswritelog(IN vlog text DEFAULT ''::text)
    LANGUAGE plpgsql
    AS $$
	BEGIN

		
		insert into pcsjimlog (log,createddate) 
		values (vlog,now());
	
	END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pcsjimlog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pcsjimlog (
    log character varying,
    createddate timestamp without time zone,
    recid bigint NOT NULL
);


--
-- Name: pcsjimlog_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pcsjimlog ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pcsjimlog_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pcstelexa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pcstelexa (
    refnum character varying,
    urlexec character varying,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    status integer DEFAULT '-1'::integer NOT NULL,
    recid bigint NOT NULL,
    deviceid character varying,
    subdeviceid character varying,
    ipaddress character varying,
    ipport character varying,
    outletno character varying,
    switch character varying,
    arrival timestamp without time zone,
    departure timestamp without time zone,
    noroom character varying,
    "json" character varying,
    typetrans character varying
);


--
-- Name: pcstelexa_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pcstelexa ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pcstelexa_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: pcsjimlog; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3364.dat

--
-- Data for Name: pcstelexa; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3361.dat

--
-- Name: pcsjimlog_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pcsjimlog_recid_seq', 1216, true);


--
-- Name: pcstelexa_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pcstelexa_recid_seq', 118, true);


--
-- Name: pcstelexa pcstelexa_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pcstelexa
    ADD CONSTRAINT pcstelexa_pk PRIMARY KEY (recid);


--
-- Name: pcsjimlog_recid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pcsjimlog_recid_idx ON public.pcsjimlog USING btree (recid);


--
-- PostgreSQL database dump complete
--

