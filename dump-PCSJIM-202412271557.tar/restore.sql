--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "PCSJIM";
--
-- Name: PCSJIM; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "PCSJIM" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


\connect "PCSJIM"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: floortype_changed(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.floortype_changed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
IF new.floortype <> OLD.floortype then
	update setuproom
	 set floortype = new.floortype
	 where floortype = old.floortype;
	
	update setuproomtariff 
	 set floortype = new.floortype
	 where floortype = old.floortype;
END IF;

RETURN NEW;
END;
$$;


--
-- Name: loadinformationroom(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.loadinformationroom(period_ timestamp with time zone DEFAULT now()) RETURNS TABLE(vacant_ text, occupied_ text, reserved_ text, outoforder_ text, duedate_ text, dirty_ text)
    LANGUAGE plpgsql
    AS $$

declare vacant text;
		occupied text;
		reserved text;
		outoforder text;
		duedate text;
		dirty text;
		jumlahdata int;
		vacountcount int;
begin	
	
	
	select count(*) into jumlahdata from setuproom s
	where s.active = 1--s.statusroom  = 'off'
	and s.statushousekeeping = 0
	and s.statusmaintenance = 0;
	
	vacountcount := jumlahdata;

	select count(*) into jumlahdata from transaksiroom s
	where s.status = 0 and s.arrival::date = period_::date;

	vacountcount := vacountcount - jumlahdata;		
	occupied := 'occupied (' || jumlahdata::text || ')';

	select count(*) into jumlahdata from transaksiroom s
	where coalesce(s.status,-1::integer) < 0 and s.arrival::date = period_::date;

	vacountcount := vacountcount - jumlahdata;	
	reserved := 'reserved (' || jumlahdata::text || ')';

	select count(*) into jumlahdata from setuproom s
	where s.statusmaintenance = 1 or s.active = 0;
	
	outoforder := 'out of order (' || jumlahdata::text || ')';
	
	select count(*) into jumlahdata from transaksiroom s
	where s.arrival::date <= period_::date
	and s.departure < period_
	and s.status < 1;

	duedate := 'due date (' || jumlahdata::text || ')';

	select count(*) into jumlahdata from setuproom s
	where s.statushousekeeping = 1;
	
	dirty := 'dirty (' || jumlahdata::text || ')';

	vacant := 'vacant (' || vacountcount::text || ')';

	return QUERY 	
	select   vacant::text 
			,occupied::text 
			,reserved::text 
			,outoforder::text 
			,duedate::text 
			,dirty::text;
	
end; $$;


--
-- Name: opencashier(character varying, money); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.opencashier(IN useridv character varying, IN saldoawalv money DEFAULT 0)
    LANGUAGE plpgsql
    AS $$
	declare statuscashier int := 0;
	BEGIN

		select s.opencashier into statuscashier from sysuser s 
		where s.username = useridv limit 1;
		
		IF coalesce(statuscashier,0::integer) = 0 then 
			insert into public.cashiertrans (userid,tanggalopen,saldoawal,status)
			values (useridv,now(),saldoawalv,0);
		
			update public.sysuser set opencashier = 1
			where username = useridv;
		else
			update public.cashiertrans set status = 1 , saldoakhir = saldoawalv , tanggalclose = now() 
			where userid = useridv and status = 0;
		
			update public.sysuser set opencashier = 0
			where username = useridv;
		
		end if;	
		
	END;
$$;


--
-- Name: roomtypes_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.roomtypes_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
IF NEW.roomtypes <> OLD.roomtypes THEN
	update setuproom
	 set roomtypes = new.roomtypes
	 where roomtypes = old.roomtypes;
	
	update setuproomtariff 
	 set roomtypes = new.roomtypes
	 where roomtypes = old.roomtypes;
END IF;

RETURN NEW;
END;
$$;


--
-- Name: setusersession(character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.setusersession(vuserid character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

declare
    sql varchar;
    countd int; 
   	sessionidv varchar;
   
	BEGIN
		sessionidv := md5( inet_client_addr()::varchar || timeofday() || inet_server_addr()::varchar || to_hex(inet_client_port()) ) ;

	    sql := 'select count(*) from sysSession where username = ''' || vuserid || ''' ';    
	   
	    execute sql into countd;
	   	   	   
	   	IF ( countd >= 1 ) THEN
			update sysSession set sessionid = sessionidv , logindatetime = NOW() where username = vuserid;
		ELSE
			insert into sysSession (sessionid, username ,logindatetime) values ( sessionidv, vuserid ,NOW() );
		END IF;
	
		update sysuser 
		set lastlogindatetime = NOW()
		where username = vuserid;
		
	    return sessionidv;
	END;
$$;


--
-- Name: sp_addreportrunner(text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_addreportrunner(vreportname text DEFAULT ''::text, vreporttitle text DEFAULT ''::text, vrptcriteria text DEFAULT ''::text, vrptparameter text DEFAULT ''::text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	declare maxrecid int8 := 0;
	BEGIN
		call sysaddreportrunner(vreportname, vreportTitle, vrptCriteria, vrptParameter);
	
		select max(recid) 			
			into maxrecid
			from sysreportrunner s ;
			
		return maxrecid;
	END;
$$;


--
-- Name: sp_calculateharga(timestamp with time zone, timestamp with time zone, text, text, text, text, text, integer, integer, integer, integer, integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_calculateharga(startdate timestamp with time zone DEFAULT now(), enddate timestamp with time zone DEFAULT now(), noroom text DEFAULT ''::text, custcodev text DEFAULT ''::text, bussinesssor text DEFAULT ''::text, seasontype text DEFAULT ''::text, ratetype text DEFAULT ''::text, adult integer DEFAULT 0, child integer DEFAULT 0, tax1 integer DEFAULT 0, tax2 integer DEFAULT 0, tax3 integer DEFAULT 0, tax4 integer DEFAULT 0, transaksiidv text DEFAULT ''::text) RETURNS TABLE(result text, day integer, hour integer, totalcharges money, discount money, totaltax money, totalrate money, extracharges money, total money, flatdiscount money, amoutpaid money, deposit money, roundoff money, balance money)
    LANGUAGE plpgsql
    AS $$

declare totalcharges_ money := 0;
		discount_ money := 0;
		totaltax_ money := 0;
		grandtotaltax money := 0;
		totalrate_ money := 0;
		extracharges_ money := 0;
		total_ money := 0;
		flatdiscount_ money := 0;
		amoutpaid_ money := 0;
		deposit_ money := 0;
		roundoff_ money := 0;
		balance_ money := 0;
		hour_ integer := 0;
		day_ integer := 0;
		sql_ varchar := '';
		dasartariff money := 0;
		roomtypev varchar := '';
		resultv varchar := '';
		floortype varchar := '';
		transdate timestamp;
		baseadult int := 0;
		basechild int := 0;
		baseadultmax int := 0;
		basechildmax int := 0;
		ratehour int := 0;
		rateday int := 0;
		transhour int := 0;
		fixedrate int := 0;
		fixedroomrate money := 0;
		looprec int := 1;
		specialseason int := 0;
		specialrate int := 0;
		plantypev varchar := '';
		valueplanv numeric := 0;
		discpctv numeric := 0;
		
begin	
	

 	sql_ := 'SELECT abs(DATE_PART(''DAY'', ''' || enddate || '''::timestamptz - ''' || startdate || '''::timestamptz)) ';     
	   
	execute sql_ into day_;	

 	sql_ := 'SELECT abs(DATE_PART(''HOUR'', ''' || enddate || '''::timestamptz - ''' || startdate || '''::timestamptz)) ';     
	   
	execute sql_ into hour_;	

	sql_ := 'select COALESCE(roomtypes,''''::text) , COALESCE(floortype,''''::text),coalesce(roomrate,0::money),coalesce(fixedrate,0::integer) from setuproom where noroom = ''' || noroom || ''' limit 1 ';    
	   
	execute sql_ into roomtypev,floortype,fixedroomrate,fixedrate;	   

	sql_ := 'select adultmax , childmax , baseadult , basechild  from setuproomtypes where roomtypes = ''' || roomtypev || ''' limit 1 ';    
	   
	execute sql_ into baseadultmax,basechildmax , baseadult , basechild;
	
	sql_ := 'select s.hour,s.day from setupratetype s where s.ratetype = ''' || coalesce(ratetype,''::text) || ''' limit 1';

	execute sql_ into ratehour,rateday;

	if(hour_ != 0 and coalesce(ratehour,0::integer) != 0) then
		-- loop per hour
		--transhour := ratehour;
		transdate := startdate;
		loop
			transdate := transdate + INTERVAL '1' hour * transhour;
			
			--RAISE NOTICE 'count = % - %',transdate , transhour;
		
			if(fixedrate != 0) then
				dasartariff = fixedroomrate;
				totalcharges_ := totalcharges_ + dasartariff ;											
			else
				call sp_stukturharga(transaksiidv,transdate,roomtypev,ratetype,floortype,bussinesssor,custcodev,noroom
									 ,adult,child,baseadult,basechild,baseadultmax,basechildmax,tax1,tax2,tax3,tax4
									 ,dasartariff,totalcharges_,totaltax_,extracharges_,grandtotaltax,discount_,flatdiscount_);
			end if;
																
			select s.definespecialseason,s.definespecialrate, coalesce(s.plantype ,'0'::varchar),s.valueplan 			
			into specialseason,specialrate,plantypev,valueplanv
			from setupbusinesssources s 		
			where s.alias = coalesce(bussinesssor,''::text) limit 1;
		
			select s.seasontype into seasontype from setupseasontype s 
			where s.active = 1
			and s.frommonth != 0
			and s.tomonth  != 0
			and s.fromday != 0
			and s.today != 0
			and date(s.yearperiod::varchar || '-' || s.frommonth::varchar ||'-'|| s.fromday::varchar) <= transdate
			and date(s.yearperiod::varchar || '-' || s.tomonth::varchar ||'-'|| s.today::varchar)  >= transdate
			limit 1;	
		
			if(coalesce(valueplanv,0::numeric) != 0::numeric and plantypev != '0') then
				if(seasontype = '' or specialseason != 1) then 
				
					if(plantypev != '2' or looprec = 1) then
						discount_ = discount_::money + (totalcharges_::numeric * coalesce(valueplanv,0::numeric) / 100::numeric)::money ;
					end if;
				end if;	
				/*
			    if (specialrate != 1) then
					if(plantypev != '2' or looprec = 1) then
						discount_ = discount_::money + (extracharges_::numeric * coalesce(valueplanv,0::numeric) / 100::numeric)::money ;
					end if;
				end if;	
				*/
			end if;
					
		
			if (transhour + ratehour >= hour_) then
				exit;
			end if;
		
			transhour := transhour + ratehour;
			looprec := looprec + 1;
		
		    EXIT WHEN transhour >= hour_;
		END LOOP;		
	else
		-- loop per tanggal
		if startdate::DATE <= enddate::DATE then
		 	transdate := startdate::DATE;
			loop
				
				if(fixedrate != 0) then
					dasartariff = fixedroomrate;
					totalcharges_ := totalcharges_ + dasartariff ;											
				else
					call sp_stukturharga(transaksiidv,transdate,roomtypev,ratetype,floortype,bussinesssor,custcodev,noroom
									 ,adult,child,baseadult,basechild,baseadultmax,basechildmax,tax1,tax2,tax3,tax4
									 ,dasartariff,totalcharges_,totaltax_,extracharges_,grandtotaltax,discount_,flatdiscount_);
				end if;
			
				select s.definespecialseason,s.definespecialrate, coalesce(s.plantype ,'0'::varchar),s.valueplan 			
				into specialseason,specialrate,plantypev,valueplanv
				from setupbusinesssources s 		
				where s.alias = coalesce(bussinesssor,''::text) limit 1;
			
				select s.seasontype into seasontype from setupseasontype s 
				where s.active = 1
				and s.frommonth != 0
				and s.tomonth  != 0
				and s.fromday != 0
				and s.today != 0
				and date(s.yearperiod::varchar || '-' || s.frommonth::varchar ||'-'|| s.fromday::varchar) <= transdate
				and date(s.yearperiod::varchar || '-' || s.tomonth::varchar ||'-'|| s.today::varchar)  >= transdate
				limit 1;	
			
				if(coalesce(valueplanv,0::numeric) != 0::numeric and plantypev != '0') then
					if(specialseason = 1) then 
						if(plantypev != '2' or looprec = 1) then
							discount_ = discount_::money + (dasartariff::numeric * coalesce(valueplanv,0::numeric) / 100::numeric)::money ;
						end if;
					end if;	
					/*
				    if (specialrate = 1) then
				    	if(plantypev != '2' or looprec = 1) then
							discount_ = discount_::money + (extracharges_::numeric * coalesce(valueplanv,0::numeric) / 100::numeric)::money ;
						end if;
					end if;	
					*/
				end if;						
						
				if (transdate::date + 1 > enddate::DATE) then
					exit;
				end if;
			
				transdate := transdate::date + 1; -- INTERVAL '1 day';
				looprec := looprec + 1;
			
			    EXIT WHEN transdate::date = enddate::DATE;
			END LOOP;
		end if;
	end if;

	IF coalesce(dasartariff,0::money) = 0::money then
		resultv := 'price not yet setup';
	    totalcharges_ := 0::money;
	else

		resultv := 'OK';

		--discount_ := 0;
		
		totalrate_ := totalcharges_ - discount_ + extracharges_;
	
		total_ := totalrate_ + grandtotaltax;
			
		select s.discpct into discpctv from setupguestlist s 
		where s.custcode = coalesce(custcodev,''::text)
		limit 1;
		
		if(coalesce(discpctv,0::numeric) != 0) then
			flatdiscount_ = (total_::numeric * coalesce(discpctv,0::numeric) / 100::numeric)::money ;  
		end if;

		--flatdiscount_ := 0;
			
		deposit_:= 0;

		-- otomatis langsung bayar
		amoutpaid_ := total_ - flatdiscount_;
		--roundoff_:= amoutpaid_ - (FLOOR( amoutpaid_::numeric / 100::numeric ) * 100::numeric)::money;
		balance_ := amoutpaid_ ;--FLOOR( amoutpaid_::numeric / 100::numeric ) * 100::numeric;
		--amoutpaid_  = balance_;
		--balance_ = 0;
		
	 end if;
		

	return QUERY 	
	select   resultv::text as result
			,day_
			,hour_
			,totalcharges_ as totalcharges
			,discount_ as discount
			,grandtotaltax as totaltax
			,totalrate_ as totalrate
			,extracharges_ as extracharges
			,total_ as total
			,flatdiscount_ as flatdiscount
			,amoutpaid_ as amoutpaid
			,deposit_ as deposit
			,roundoff_ as roundoff
			,balance_ as balance;
	
end; $$;


--
-- Name: sp_cashiertrans(text, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_cashiertrans(vuserid text DEFAULT ''::text, vsaldoawal numeric DEFAULT (0)::numeric) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
	BEGIN

		call opencashier(vuserid, vsaldoawal::money);
	
		return 'ok';
	END;
$$;


--
-- Name: sp_checkavailableroom(timestamp with time zone, timestamp with time zone, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_checkavailableroom(startdate timestamp with time zone DEFAULT now(), enddate timestamp with time zone DEFAULT now(), noroom text DEFAULT ''::text, custcode text DEFAULT ''::text) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

declare resultv varchar := 'ok';
		isavail int := 0;
		sql_ varchar;
		active int := 0;
		statushousekeeping int := 0;
		statusmaintenance int := 0;
		statusroom varchar := '';	
begin	
	
	
	sql_ := 'SELECT count(*) from transaksiroom where coalesce(status,0::integer) < 1 and noroom = ''' || noroom || '''  ';     
	sql_ := sql_ || ' and ((''' || startdate || ''' between arrival::date and departure) ';
  	sql_ := sql_ || ' or   (''' || enddate   || ''' between arrival::date and departure)) ';

	execute sql_ into isavail;	

	sql_ := 'select active,statushousekeeping,statusmaintenance,statusroom from setuproom s  where s.noroom = ''' || noroom || ''' limit 1 ';    
	   
	execute sql_ into active,statushousekeeping,statusmaintenance,statusroom;

	if(coalesce(isavail,0::integer) > 0) then
		resultv := 'not available';
	elseif(coalesce(active,0::integer) = 0) then
		resultv := 'room is not active';
	elseif(coalesce(statushousekeeping,0::integer) != 0) then
		resultv := 'room is dirty';
	elseif(coalesce(statusmaintenance,0::integer) != 0) then
		resultv := 'room is under maintenance';		
	end if;

 	return resultv;
	
end; $$;


--
-- Name: sp_prosesbatchroom(text, timestamp with time zone, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_prosesbatchroom(vnoroom text DEFAULT ''::text, periodv timestamp with time zone DEFAULT now(), useridv character varying DEFAULT ''::character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$

declare CursorQ cursor FOR			
			SELECT T1.noroom,T1.arrival,T1.departure,T1.Transaksiid,coalesce(T1.status, -1::integer),T2.statushousekeeping,T2.statusmaintenance from public.transaksiroom T1 
			left join public.setuproom T2 on T2.noroom = T1.noroom
			where coalesce(T1.status, -1::integer) <= 0 and T1.manualcheckin = 0
			and (T1.noroom = vnoroom::varchar or vnoroom::varchar = '')
			order by T1.noroom,T1.arrival asc, T1.departure asc;
		
		CursorHouse cursor for
			SELECT T1.noroom,T1.arrival,T1.departure,T1.transid,coalesce(T1.status, -1::integer) from public.housekeepingroom T1 
			where coalesce(T1.status, -1::integer) <= 0 
			and (T1.noroom = vnoroom::varchar or vnoroom::varchar = '')
			order by T1.noroom,T1.arrival asc, T1.departure asc;

		CursorMaintenance cursor for
			SELECT T1.noroom,T1.arrival,T1.departure,T1.transid,coalesce(T1.status, -1::integer) from public.maitenanceroom T1 
			where coalesce(T1.status, -1::integer) <= 0 
			and (T1.noroom = vnoroom::varchar or vnoroom::varchar = '')
			order by T1.noroom,T1.arrival asc, T1.departure asc;
		
		noroomv varchar;
		arrivalv timestamp;
		departurev timestamp;
	    transaksiidv varchar;
	    sqlv varchar;
	   	countlink int := 0;
	    recidv int := 0;
	    deviceid varchar;
	    subdeviceid varchar;
	    ipaddress varchar;
	    ipport varchar;
	    outletno varchar;
	    resultv varchar := '';
	   	skalar varchar := '';
	    statusv int := 0;
	    statushou int := 0;
	    statusmai int := 0;
	    statusroom varchar := '';
	BEGIN

		
	OPEN CursorQ;

    -- Fetch rows and return
    LOOP
        FETCH NEXT FROM CursorQ INTO noroomv,arrivalv,departurev,transaksiidv,statusv,statushou,statusmai;
        EXIT WHEN NOT FOUND;
       
        -- checkin
		if (arrivalv <= periodv and departurev >= periodv and statusv < 0 and statushou = 0) then			       
       		update public.transaksiroom set status = 0 
									,updatedatetime = now() 
									,actualcheckin = now() 
									,updatedby = useridv
            	   where transaksiid = transaksiidv;       
    		/*        	  
			sqlv := 'SELECT count(*) FROM pg_extension where extname = ''dblink'' ';

			execute sqlv into countlink;	
	
            if(coalesce(countlink,0::integer) = 0) then	
				create extension dblink;
			end if;
			*/
		
			select vwroom.deviceid ,vwroom.subdeviceid ,vwroom.ipaddress ,vwroom.ipport ,vwroom.outletno ,vwroom.statusroom 
			into deviceid,subdeviceid,ipaddress,ipport,outletno,statusroom from vwRoom where noroom = noroomv;            	              	  
            
			--if(statusroom != 'on') then -- check kalo uda on ga perlu dinyalain lagi 
				skalar := 'on';
				SELECT dblink_connect('pcstelexa','host=192.168.1.215 port=5432 dbname=PCSBatch user=postgres password=postgres123 options=-csearch_path=') into resultv;
			
				sqlv := ' ''insert into public.pcstelexa (refnum,urlexec,createddate,createdby';
			    sqlv := sqlv || ',deviceid,subdeviceid,ipaddress,ipport,outletno,switch,status,arrival,departure,noroom,typetrans)';
			    sqlv := sqlv || 'values (''''' || transaksiidv || ''''','''''''', NOW(),''''' ||useridv|| '''''';
			    sqlv := sqlv || ', ''''' || deviceid || ''''', ''''' || subdeviceid || ''''', ''''' || ipaddress || ''''', ''''' || ipport || ''''' ';
			    sqlv := sqlv || ', ''''' || outletno || ''''', ''''' || skalar || ''''' ';		   
			    sqlv := sqlv || ',-1 , ''''' || arrivalv || ''''' , ''''' || departurev || ''''',''''' || noroomv || ''''',''''reservation'''') RETURNING recid;''';
							
				sqlv := 'select * FROM dblink(''pcstelexa'', '|| sqlv ||')';
			    sqlv := sqlv || 'AS t(recid INTEGER); ';
	
			    execute sqlv into recidv;	
			    
			    --RAISE NOTICE 'sql = % ',sqlv ;
			    
				SELECT dblink_disconnect('pcstelexa') into resultv;         	  
				--DROP EXTENSION IF EXISTS dblink;
       		--end if;
        -- checkout
		elseif (departurev <= periodv and statusv = 0 and statushou = 0) then			

			--RAISE NOTICE 'tai%',recidv;
       		
			update public.transaksiroom set status = 1 
									,updatedatetime = now() 
									,actualcheckout = now() 
									,updatedby = useridv
            	   where transaksiid = transaksiidv;
        elseif (departurev <= periodv and statusv < 0 and statushou = 0) then
        	update public.transaksiroom set status = 2 
									,updatedatetime = now() 
									,actualcheckout = now() 
									,actualcheckin = now()
									,updatedby = useridv
            	   where transaksiid = transaksiidv;        
		end if;       	
       	
    END LOOP;

   CLOSE CursorQ;
		

	OPEN CursorHouse;

    LOOP
        FETCH NEXT FROM CursorHouse INTO noroomv,arrivalv,departurev,transaksiidv,statusv;
        EXIT WHEN NOT FOUND;
       
        -- checkin
		if (arrivalv <= periodv and departurev >= periodv and statusv < 0) then			       
       		update public.housekeepingroom set status = 0 
									,updateddate = now() 
									,updatedby = useridv
            	   where transid = transaksiidv;       

			update public.setuproom set statushousekeeping = 1
            						,updateddatetime = now() 
									,updatedby = useridv
            	   where noroom = noroomv and statushousekeeping = 0;   
            	  		
			select vwroom.deviceid ,vwroom.subdeviceid ,vwroom.ipaddress ,vwroom.ipport ,vwroom.outletno ,vwroom.statusroom 
			into deviceid,subdeviceid,ipaddress,ipport,outletno,statusroom  from vwRoom where noroom = noroomv;            	              	  
			
			if(statusroom != 'on') then -- check kalo uda on ga perlu dinyalain lagi 
				
				skalar := 'on';
				SELECT dblink_connect('pcstelexa','host=192.168.1.215 port=5432 dbname=PCSBatch user=postgres password=postgres123 options=-csearch_path=') into resultv;
			
				sqlv := ' ''insert into public.pcstelexa (refnum,urlexec,createddate,createdby';
			    sqlv := sqlv || ',deviceid,subdeviceid,ipaddress,ipport,outletno,switch,status,arrival,departure,noroom,typetrans)';
			    sqlv := sqlv || 'values (''''' || transaksiidv || ''''','''''''', NOW(),''''' ||useridv|| '''''';
			    sqlv := sqlv || ', ''''' || deviceid || ''''', ''''' || subdeviceid || ''''', ''''' || ipaddress || ''''', ''''' || ipport || ''''' ';
			    sqlv := sqlv || ', ''''' || outletno || ''''', ''''' || skalar || ''''' ';		   
			    sqlv := sqlv || ',-1 , ''''' || arrivalv || ''''' , ''''' || departurev || ''''',''''' || noroomv || ''''',''''housekeeping'''') RETURNING recid;''';
							
				sqlv := 'select * FROM dblink(''pcstelexa'', '|| sqlv ||')';
			    sqlv := sqlv || 'AS t(recid INTEGER); ';
	
			    execute sqlv into recidv;	
			    		    
				SELECT dblink_disconnect('pcstelexa') into resultv;         	  
       		end if;
        -- checkout
		elseif (departurev <= periodv and statusv = 0) then			
			update public.housekeepingroom set status = 1 
									,updateddate = now() 
									,updatedby = useridv
            	   where transid = transaksiidv;

			update public.setuproom set statushousekeeping = 0
            						,updateddatetime = now() 
									,updatedby = useridv
            	   where noroom = noroomv and statushousekeeping = 1; 
        elseif (departurev <= periodv and statusv < 0) then
        	update public.housekeepingroom set status = 2 
									,updateddate = now() 
									,updatedby = useridv
            	   where transid = transaksiidv;        

			update public.setuproom set statushousekeeping = 0
            						,updateddatetime = now() 
									,updatedby = useridv
            	   where noroom = noroomv and statushousekeeping = 1; 

		end if;       	
       	
    END LOOP;

   CLOSE CursorHouse;  
  
  
OPEN CursorMaintenance;

    LOOP
        FETCH NEXT FROM CursorMaintenance INTO noroomv,arrivalv,departurev,transaksiidv,statusv;
        EXIT WHEN NOT FOUND;
       
        -- checkin
		if (arrivalv <= periodv and departurev >= periodv and statusv < 0) then			       
       		update public.maitenanceroom set status = 0 
									,updateddate = now() 
									,updatedby = useridv
            	   where transid = transaksiidv;       

            update public.setuproom set statusmaintenance = 1
            						,updateddatetime = now() 
									,updatedby = useridv
            	   where noroom = noroomv and statusmaintenance = 0;       
            	  		
			select vwroom.deviceid ,vwroom.subdeviceid ,vwroom.ipaddress ,vwroom.ipport ,vwroom.outletno ,vwroom.statusroom 
			into deviceid,subdeviceid,ipaddress,ipport,outletno,statusroom from vwRoom where noroom = noroomv;            	              	  
           
			if(statusroom != 'on') then -- check kalo uda on ga perlu dinyalain lagi 
				skalar := 'on';
	
				SELECT dblink_connect('pcstelexa','host=192.168.1.215 port=5432 dbname=PCSBatch user=postgres password=postgres123 options=-csearch_path=') into resultv;
			
				sqlv := ' ''insert into public.pcstelexa (refnum,urlexec,createddate,createdby';
			    sqlv := sqlv || ',deviceid,subdeviceid,ipaddress,ipport,outletno,switch,status,arrival,departure,noroom,typetrans)';
			    sqlv := sqlv || 'values (''''' || transaksiidv || ''''','''''''', NOW(),''''' ||useridv|| '''''';
			    sqlv := sqlv || ', ''''' || deviceid || ''''', ''''' || subdeviceid || ''''', ''''' || ipaddress || ''''', ''''' || ipport || ''''' ';
			    sqlv := sqlv || ', ''''' || outletno || ''''', ''''' || skalar || ''''' ';		   
			    sqlv := sqlv || ',-1 , ''''' || arrivalv || ''''' , ''''' || departurev || ''''',''''' || noroomv || ''''',''''maintenance'''') RETURNING recid;''';
							
				sqlv := 'select * FROM dblink(''pcstelexa'', '|| sqlv ||')';
			    sqlv := sqlv || 'AS t(recid INTEGER); ';
	
			    execute sqlv into recidv;	
			    		    
				SELECT dblink_disconnect('pcstelexa') into resultv;         	  
       		end if;
        -- checkout
		elseif (departurev <= periodv and statusv = 0) then			
			update public.maitenanceroom set status = 1 
									,updateddate = now() 
									,updatedby = useridv
            	   where transid = transaksiidv;

			update public.setuproom set statusmaintenance = 0
            						,updateddatetime = now() 
									,updatedby = useridv
            	   where noroom = noroomv and statusmaintenance = 1;  

        elseif (departurev <= periodv and statusv < 0) then
        	update public.maitenanceroom set status = 2 
									,updateddate = now() 
									,updatedby = useridv
            	   where transid = transaksiidv;      

			update public.setuproom set statusmaintenance = 0
            						,updateddatetime = now() 
									,updatedby = useridv
            	   where noroom = noroomv and statusmaintenance = 1;    
		end if;       	
       	
    END LOOP;

   CLOSE CursorMaintenance;    
  
   return recidv;

	END;
$$;


--
-- Name: sp_stukturharga(text, timestamp with time zone, text, text, text, text, text, text, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, money, money, money, money, money, money, money); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.sp_stukturharga(IN transaksiidv text DEFAULT ''::text, IN transdate timestamp with time zone DEFAULT now(), IN roomtypev text DEFAULT ''::text, IN ratetype text DEFAULT ''::text, IN floortype text DEFAULT ''::text, IN bussinesssor text DEFAULT ''::text, IN custcode text DEFAULT ''::text, IN noroom text DEFAULT ''::text, IN adult integer DEFAULT 0, IN child integer DEFAULT 0, IN baseadult integer DEFAULT 0, IN basechild integer DEFAULT 0, IN baseadultmax integer DEFAULT 0, IN basechildmax integer DEFAULT 0, IN tax1 integer DEFAULT 0, IN tax2 integer DEFAULT 0, IN tax3 integer DEFAULT 0, IN tax4 integer DEFAULT 0, INOUT dasartariff money DEFAULT 0, INOUT totalcharges_ money DEFAULT 0, INOUT totaltax_ money DEFAULT 0, INOUT extracharges_ money DEFAULT 0, INOUT grandtotaltax money DEFAULT 0, INOUT discount_ money DEFAULT 0, INOUT flatdiscount_ money DEFAULT 0)
    LANGUAGE plpgsql
    AS $$
declare seasontype varchar := '';
		dasaradult money := 0;
		dasarchild money := 0;
		usetax int := 0;
		vtax1 numeric := 0;
		vtax2 numeric := 0;
		vtax3 numeric := 0;
		vtax4 numeric := 0;
		vtax1amount money := 0;
		vtax2amount money := 0;
		vtax3amount money := 0;
		vtax4amount money := 0;		
		sql_ varchar := '';
		_createdby varchar:='admin';
		_counttrans int := 0;	
		specialseason int := 0;
		specialrate int := 0;
		plantypev varchar := '';
		valueplanv numeric := 0;
		discount_ money := 0;
		totalratetrans money := 0;
		totalhari int := 0;
		
begin
  
		-- start calculate harga 		
		select s.seasontype into seasontype from setupseasontype s 
		where s.active = 1
		and s.frommonth != 0
		and s.tomonth  != 0
		and s.fromday != 0
		and s.today != 0
		and date(s.yearperiod::varchar || '-' || s.frommonth::varchar ||'-'|| s.fromday::varchar) <= transdate
		and date(s.yearperiod::varchar || '-' || s.tomonth::varchar ||'-'|| s.today::varchar)  >= transdate
		limit 1;		
	
		sql_ :=         ' select COALESCE(s.tariff,0::money),COALESCE(s.extraadult,0::money),COALESCE(s.extrachild,0::money),COALESCE(s.usetax,0::integer)  from setuproomtariff s ';
		sql_ := sql_ || ' where (s.roomtypes = ''' || coalesce(roomtypev,''::text) || ''' or s.roomtypes = '''') ';
		sql_ := sql_ || ' and (s.ratetypes = ''' || coalesce(ratetype,''::text) || ''' or s.ratetypes = '''') ';
		sql_ := sql_ || ' and (s.floortype = ''' || coalesce(floortype,''::text) || ''' or s.floortype = '''') ';
		sql_ := sql_ || ' and (s.bussinesssource = ''' || coalesce(bussinesssor,''::text) || ''' or s.bussinesssource = '''') ';
		sql_ := sql_ || ' and (s.seasontype = ''' || coalesce(seasontype,''::text) || ''' or s.seasontype = '''') ';
		sql_ := sql_ || ' and (s.custcode = ''' || coalesce(custcode,''::text) || ''' or s.custcode = '''') ';
		sql_ := sql_ || ' and (s.noroom = ''' || coalesce(noroom,''::text) || ''' or s.noroom = '''') ';
		sql_ := sql_ || ' and s.active = 1 ';
		sql_ := sql_ || ' order by roomtypes , floortype, ratetypes ,bussinesssource ,seasontype ,custcode ,noroom ';
		sql_ := sql_ || ' limit 1 ';			
	
		execute sql_ into dasartariff, dasaradult ,dasarchild,usetax;	
	
		if(adult - baseadultmax > 0 and adult > baseadultmax) 
		then
			extracharges_ := extracharges_ + ((adult - baseadultmax) * dasaradult);		
		end if;
	
		if(child - basechildmax > 0 and child > basechildmax) 
		then
			extracharges_ := extracharges_ + ((child - basechildmax) * dasarchild);		
		end if;
		
		IF coalesce(usetax,0::integer) = 1 then -- tax
		
			select s.tax1,s.tax2,s.tax3,s.tax4,s.tax1amount,s.tax2amount,s.tax3amount,s.tax4amount 
			into vtax1,vtax2,vtax3,vtax4,vtax1amount,vtax2amount,vtax3amount,vtax4amount
			from setuptax s where s.fromamount < dasartariff and s.toamount >= dasartariff limit 1;
			
			totaltax_ := 0;
		
			if(tax1 != 0) then
				if(vtax1 != 0) then
					totaltax_ := ((dasartariff+extracharges_) * vtax1 / 100);
				elseif(vtax1amount != 0::money) then
					totaltax_ := dasartariff + extracharges_ + vtax1amount;				
				end if;
			end if;
			
			if(tax2 != 0) then
				if(vtax2 != 0) then
					totaltax_ := totaltax_ + (((dasartariff+extracharges_) + totaltax_) * vtax2 / 100);
				elseif(vtax2amount != 0::money) then
					totaltax_ := totaltax_ + (((dasartariff+extracharges_) + totaltax_) + vtax2amount);				
				end if;
			end if;
		
			if(tax3 != 0) then
				if(vtax3 != 0) then
					totaltax_ := totaltax_ + (((dasartariff+extracharges_) + totaltax_) * vtax3 / 100);
				elseif(vtax3amount != 0::money) then
					totaltax_ := totaltax_ + (((dasartariff+extracharges_) + totaltax_) + vtax3amount);				
				end if;
			end if;
		
			if(tax4 != 0) then
				if(vtax4 != 0) then
					totaltax_ := totaltax_ + (((dasartariff+extracharges_) + totaltax_) * vtax4 / 100);
				elseif(vtax4amount != 0::money) then
					totaltax_ := totaltax_ + (((dasartariff+extracharges_) + totaltax_) + vtax4amount);				
				end if;
			end if;
		
		end if;		
			
		totalcharges_ := totalcharges_ + dasartariff ;
		grandtotaltax := grandtotaltax + totaltax_;
		-- end calculate harga
		--check discount
	
		select s.definespecialseason,s.definespecialrate, coalesce(s.plantype ,'0'::varchar),s.valueplan 			
		into specialseason,specialrate,plantypev,valueplanv
		from setupbusinesssources s 		
		where s.alias = coalesce(bussinesssor,''::text) limit 1;
			
		if(coalesce(valueplanv,0::numeric) != 0::numeric and plantypev != '0') then
			if(specialseason = 1) then 
				if(plantypev != '2' or totaltax_ = 0::money) then
					discount_ = (dasartariff::numeric * coalesce(valueplanv,0::numeric) / 100::numeric)::money ;
				end if;
			end if;	
			/*
		    if (specialrate = 1) then
		    	if(plantypev != '2' or looprec = 1) then
					discount_ = discount_::money + (extracharges_::numeric * coalesce(valueplanv,0::numeric) / 100::numeric)::money ;
				end if;
			end if;	
			*/
		end if;						
									
	
	
		if(transaksiidv != '' )then
				select count(*)::integer into _counttrans
				from transaksiroomratedetail t where t.transaksiid = transaksiidv and tanggal = transdate;
				
				--RAISE NOTICE 'count = % - %',_counttrans , transdate;
				select 
				 extract(day from departure::timestamp)  - extract(day from arrival::timestamp) as TotalHari
				,t.totalcharges
				into totalhari,totalratetrans
				from transaksiroom t where t.transaksiid = transaksiidv;						

				totalratetrans := totalratetrans / totalhari;

				if(_counttrans != 0) then
					update public.transaksiroomratedetail
						set totalcharges = totalratetrans
						   ,discount = 0
						   ,totaltax = 0
						   ,total = totalratetrans
						   ,updateddate = NOW()
						   ,updatedby = _createdby
					where transaksiid = transaksiidv and tanggal = transdate;
				
				else
					insert into public.transaksiroomratedetail (transaksiid,tanggal,totalcharges
																,discount,totaltax,total,ratetypes,seasontype
																,extraadult,extrachild,createddate,createdby)
					values (transaksiidv,transdate,totalratetrans
							,0,0,totalratetrans
							,ratetype ,seasontype, ((adult - baseadultmax) * dasaradult) , ((child - basechildmax) * dasarchild) ,NOW(),_createdby);
				end if;
		end if;
	
	
	
end;
$$;


--
-- Name: spgeneratereportdaily(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.spgeneratereportdaily(vperiod timestamp with time zone DEFAULT now()) RETURNS TABLE(tanggal timestamp without time zone, roomsolddaily integer, roomsolddailywalkin integer, roomsolddailyreddoor integer, roomsoldmonthly integer, roomsoldmonthlywalkin integer, roomsoldmonthlyreddoor integer, occupancydaily numeric, occupancymonthly numeric, arrdaily numeric, arrmonthly numeric, roomrevenuedaily numeric, roomrevenuemonthly numeric, noshowdaily numeric, noshowmonthly numeric)
    LANGUAGE plpgsql
    AS $$
declare vRoomSoldDaily integer;
 		vRoomSoldDailyWalkin integer;
		vRoomSoldDailyReddoor integer;
		vOccupancyDaily decimal;
		vOccupancyMonthly decimal;
		vARRDailyWalkin decimal;
		vARRDailyReddoor decimal;
		vRoomRevenueDailyWalkin decimal;
		vRoomRevenueDailyReddoor decimal;
		vARRDaily decimal;
		vARRMonthly decimal;
		vRoomSoldMonthly integer;
		vRoomSoldMonthlyWalkin integer;
		vRoomSoldMonthlyReddoor integer;
		vARRMonthlyWalkin decimal;
		vARRMonthlyReddoor decimal;
		vRoomRevenueMonthlyWalkin decimal;
		vRoomRevenueMonthlyReddoor decimal;
		vNoShowDaily decimal;
		vNoShowMonthly decimal;
		vTotalroom integer;
		vRoomRevenueDaily decimal;
		vRoomRevenueMonthly decimal;
		vtanggal timestamp without time zone;
		totalhari int;
	BEGIN
				

	select T1.roomssolddaily, T1.arrdaily,T1.roomrevenuedaily,T1.TotalRoom
		into vRoomSoldDailyWalkin , vARRDailyWalkin , vRoomRevenueDailyWalkin , vTotalroom
		from vwdailyreport T1
			where T1.tanggal = vperiod::date 
			and T1.tipetrans = 'walkin'
			and T1.Status = 1
			and T1.period = 'daily';
		
	select T1.roomssolddaily, T1.arrdaily,T1.roomrevenuedaily,T1.TotalRoom
		into vRoomSoldDailyReddoor , vARRDailyReddoor , vRoomRevenueDailyReddoor , vTotalroom
		from vwdailyreport T1
			where T1.tanggal = vperiod::date 
			and T1.tipetrans = 'reservation'
			and T1.Status = 1
			and T1.period = 'daily';
		
	SELECT count(t3.*) AS roomssolddaily,
	    avg(t3.totalrate::numeric) AS arrdaily,
	    sum(t3.totalrate::numeric) AS roomrevenuedaily
	   into vRoomSoldMonthlyWalkin , vARRMonthlyWalkin , vRoomRevenueMonthlyWalkin
	   FROM transaksiroom t3
	  WHERE EXTRACT(month FROM t3.departure::date) = EXTRACT(month FROM vperiod::date)
		and coalesce(T3.status, -1::smallint) = 1
		and T3.tipetrans =  'walkin'
	  GROUP BY (EXTRACT(month FROM t3.departure::date)), t3.tipetrans, coalesce(T3.status, -1::smallint);
		
	SELECT count(t3.*) AS roomssolddaily,
	    avg(t3.totalrate::numeric) AS arrdaily,
	    sum(t3.totalrate::numeric) AS roomrevenuedaily
	   into vRoomSoldMonthlyReddoor , vARRMonthlyReddoor , vRoomRevenueMonthlyReddoor 
	   FROM transaksiroom t3
	  WHERE EXTRACT(month FROM t3.departure::date) = EXTRACT(month FROM vperiod::date)
		and coalesce(T3.status, -1::smallint) = 1
		and T3.tipetrans =  'reservation'
	  GROUP BY (EXTRACT(month FROM t3.departure::date)), t3.tipetrans, coalesce(T3.status, -1::smallint);


		vRoomSoldDaily := coalesce(vRoomSoldDailyWalkin, 0::integer) + coalesce(vRoomSoldDailyReddoor, 0::integer);
		vRoomSoldMonthly := coalesce(vRoomSoldMonthlyWalkin, 0::integer) + coalesce(vRoomSoldMonthlyReddoor, 0::integer);

		SELECT  
	    DATE_PART('days', 
	        DATE_TRUNC('month', vperiod) 
	        + '1 MONTH'::INTERVAL 
	        - '1 DAY'::INTERVAL
	    ) into totalhari;

 		SELECT count(*) AS count
		into vTotalroom
           FROM setuproom
          WHERE setuproom.active = 1;

		vOccupancyDaily := coalesce(vRoomSoldDaily::float, 0::float) / coalesce(vTotalroom::float, 0::float) * 100;
		vOccupancyMonthly := coalesce(vRoomSoldMonthly::float, 0::float) / (coalesce(vTotalroom::float, 0::float) * totalhari) * 100;

		vARRDaily := (coalesce(vARRDailyWalkin, 0::float) + coalesce(vARRDailyReddoor, 0::float)) / 2;
		vARRMonthly := (coalesce(vARRMonthlyWalkin, 0::float) + coalesce(vARRMonthlyReddoor, 0::float)) / 2;

		vRoomRevenueDaily := coalesce(vRoomRevenueDailyWalkin, 0::float) + coalesce(vRoomRevenueDailyReddoor, 0::float);
		vRoomRevenueMonthly := coalesce(vRoomRevenueMonthlyWalkin, 0::float) + coalesce(vRoomRevenueMonthlyReddoor, 0::float);

		select T1.roomssolddaily from vwdailyreport t1
		into vNoShowDaily
		where t1.status = 3		
		and T1.tanggal = vperiod::date 
		and T1.period = 'daily';


		SELECT count(t3.*) AS roomssolddaily
		   into vNoShowMonthly
		   FROM transaksiroom t3
		  WHERE EXTRACT(month FROM t3.departure::date) = EXTRACT(month FROM vperiod::date)
			and coalesce(T3.status, -1::smallint) = 3
		  GROUP BY (EXTRACT(month FROM t3.departure::date)), t3.tipetrans, coalesce(T3.status, -1::smallint);

		vtanggal := vperiod::Date;


 		vRoomSoldDaily := coalesce(vRoomSoldDaily::float, 0::integer);
		vRoomSoldDailyWalkin := coalesce(vRoomSoldDailyWalkin::float, 0::integer);
 	    vRoomSoldDailyReddoor := coalesce(vRoomSoldDailyReddoor::float, 0::integer);
	  	vRoomSoldMonthly := coalesce(vRoomSoldMonthly::float, 0::integer);
	  	vRoomSoldMonthlyWalkin := coalesce(vRoomSoldMonthlyWalkin::float, 0::integer);
	  	vRoomSoldMonthlyReddoor := coalesce(vRoomSoldMonthlyReddoor::float, 0::integer);
	  	vOccupancyDaily := coalesce(vOccupancyDaily::float, 0::float);
		vOccupancyMonthly := coalesce(vOccupancyMonthly::float, 0::float);
		vARRDaily := coalesce(vARRDaily::float, 0::float);
		vARRMonthly := coalesce(vARRMonthly::float, 0::float);
		vRoomRevenueDaily := coalesce(vRoomRevenueDaily::float, 0::float);		
		vRoomRevenueMonthly := coalesce(vRoomRevenueMonthly::float, 0::float);


		RETURN QUERY
			Select vtanggal
				  ,vRoomSoldDaily
				  ,vRoomSoldDailyWalkin
				  ,vRoomSoldDailyReddoor
				  ,vRoomSoldMonthly
				  ,vRoomSoldMonthlyWalkin
				  ,vRoomSoldMonthlyReddoor
				  ,vOccupancyDaily
				  ,vOccupancyMonthly
				  ,vARRDaily
				  ,vARRMonthly
				  ,vRoomRevenueDaily		
				  ,vRoomRevenueMonthly		
				  ,coalesce(vNoShowDaily, 0::integer)		
				  ,coalesce(vNoShowMonthly, 0::integer)		
			;	   	
		
	
	END;
$$;


--
-- Name: sysaddreportrunner(character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.sysaddreportrunner(IN vreportname character varying, IN vreporttitle character varying, IN vrptcriteria character varying, IN vrptparameter character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN

		insert into public.sysreportrunner (reportname,rptcriteria,rptparameter,reporttitle)
		values (vreportname,vrptCriteria,vrptParameter,vreportTitle);
				
	END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cashiertrans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cashiertrans (
    userid character varying,
    tanggalopen timestamp without time zone,
    saldoawal money,
    status smallint,
    recid bigint NOT NULL,
    saldoakhir money,
    tanggalclose timestamp without time zone
);


--
-- Name: cashiertrans_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cashiertrans ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cashiertrans_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: housekeepingroom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.housekeepingroom (
    noroom character varying,
    arrival timestamp without time zone,
    departure timestamp without time zone,
    transid character varying,
    status smallint,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    keterangan character varying,
    recid bigint NOT NULL
);


--
-- Name: housekeepingroom_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.housekeepingroom ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.housekeepingroom_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jumlahdata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jumlahdata (
    count bigint
);


--
-- Name: logdaily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logdaily (
    datetime timestamp without time zone,
    outletno character varying,
    current numeric,
    voltage numeric,
    realpower numeric,
    reactivepower numeric,
    apparentpower numeric,
    "5minpowerconsumption" numeric,
    recid bigint NOT NULL,
    deviceid character varying,
    subdeviceid character varying,
    createdby character varying
);


--
-- Name: logdaily_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.logdaily ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.logdaily_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: maintenancetype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenancetype (
    type character varying,
    description character varying,
    period smallint DEFAULT 30,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL,
    active smallint DEFAULT 1
);


--
-- Name: maintenancetype_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.maintenancetype ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.maintenancetype_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: maitenanceroom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maitenanceroom (
    noroom character varying,
    arrival timestamp without time zone,
    departure timestamp without time zone,
    transid character varying,
    status smallint,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    keterangan character varying,
    recid bigint NOT NULL,
    controltype character varying
);


--
-- Name: maitenanceroom_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.maitenanceroom ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.maitenanceroom_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupbusinesssources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupbusinesssources (
    alias character varying,
    companyname character varying NOT NULL,
    firstname character varying,
    lastname character varying,
    description character varying,
    address character varying,
    address2 character varying,
    city character varying,
    postalcode character varying,
    state character varying,
    country character varying,
    phone character varying,
    fax character varying,
    email character varying,
    website character varying,
    creditcardtype character varying,
    cardholder character varying,
    creditcardno character varying,
    ccexpdate timestamp without time zone,
    iatano character varying,
    regno character varying,
    regno1 character varying,
    regno2 character varying,
    acnumber character varying,
    definespecialseason smallint,
    definespecialrate smallint,
    plantype character varying,
    valueplan numeric,
    term integer,
    createddate timestamp without time zone DEFAULT (now())::timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL,
    marketplace character varying
);


--
-- Name: setupbusinesssources_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupbusinesssources ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupbusinesssources_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupdevice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupdevice (
    deviceid character varying NOT NULL,
    description character varying,
    createddate date,
    recid integer NOT NULL,
    createdby character varying,
    createdtime timestamp without time zone,
    ipaddress character varying,
    ipport character varying,
    updatedatetime timestamp without time zone,
    updatedby character varying,
    ipaddresslan character varying,
    ipaddresswifi character varying,
    tipeipaddress smallint DEFAULT 0
);


--
-- Name: COLUMN setupdevice.tipeipaddress; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.setupdevice.tipeipaddress IS '0 -> LAN , 1 -> WIFI';


--
-- Name: setupdevice_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupdevice ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupdevice_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupfloor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupfloor (
    floortype character varying NOT NULL,
    description character varying,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL
);


--
-- Name: setupfloor_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupfloor ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupfloor_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupguestlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupguestlist (
    custcode character varying NOT NULL,
    firstname character varying,
    lastname character varying,
    identificationid character varying,
    phone character varying,
    email character varying,
    lasttransaksiid character varying,
    discountcode character varying,
    discpct numeric,
    npwp character varying,
    telephone character varying,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL,
    businesscode character varying,
    paymenttype character varying,
    creditcardno character varying,
    creditlimit money,
    statusblock character varying NOT NULL,
    address character varying,
    picprofile character varying,
    street character varying,
    city character varying,
    state character varying,
    zipcode character varying,
    country character varying,
    guesttype character varying,
    regno character varying,
    identificationtype character varying,
    identificationexpdate timestamp without time zone,
    vehiclelicenseplate character varying,
    vehiclecolor character varying,
    vehiclecompany character varying,
    vehiclemodel character varying,
    vehicleyear integer,
    maritalstatus character varying,
    anniversarydate timestamp without time zone,
    children integer,
    spousebirthdate timestamp without time zone,
    education character varying,
    occupation character varying,
    income money,
    nationality character varying,
    language1 character varying,
    language2 character varying,
    allergies character varying,
    bloodtype character varying,
    officeadd character varying,
    office character varying,
    residential character varying,
    fax character varying,
    website character varying,
    followup character varying,
    heardfrom character varying,
    denial character varying,
    birthdate timestamp without time zone,
    gender character varying,
    ktpprofile character varying
);


--
-- Name: setupguestlist_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupguestlist ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupguestlist_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupoutlet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupoutlet (
    outletno character varying NOT NULL,
    deviceid character varying NOT NULL,
    subdeviceid character varying NOT NULL,
    createddate date,
    createdtime timestamp without time zone,
    recid bigint NOT NULL,
    description character varying,
    createdby character varying,
    updatedatetime timestamp without time zone,
    updatedby character varying
);


--
-- Name: setupoutlet_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupoutlet ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupoutlet_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setuppaymenttype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setuppaymenttype (
    paymenttype character varying,
    description character varying,
    recid bigint NOT NULL,
    active smallint,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying
);


--
-- Name: setuppaymenttype_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setuppaymenttype ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setuppaymenttype_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupratetype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupratetype (
    ratetype character varying NOT NULL,
    keterangan character varying,
    hour smallint DEFAULT 0 NOT NULL,
    day smallint DEFAULT 0 NOT NULL,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL
);


--
-- Name: setupratetype_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupratetype ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupratetype_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setuproom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setuproom (
    outletno character varying,
    noroom character varying,
    description character varying,
    recid bigint NOT NULL,
    createddatetime timestamp without time zone,
    createdby character varying,
    updateddatetime timestamp without time zone,
    updatedby character varying,
    numbersequencetrans character varying,
    refrecidoutlet bigint,
    roomrate money,
    active smallint DEFAULT 1,
    statushousekeeping smallint DEFAULT 0 NOT NULL,
    statusmaintenance smallint DEFAULT 0 NOT NULL,
    statusroom character varying DEFAULT 'off'::character varying NOT NULL,
    roomtypes character varying,
    phoneext character varying,
    dataext character varying,
    keycard character varying,
    powercode character varying,
    roomamenities character varying,
    housekeepingday character varying,
    allowsmoking smallint,
    floortype character varying,
    lockprice smallint,
    fixedrate smallint
);


--
-- Name: setuproom_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setuproom ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setuproom_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setuproomamenities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setuproomamenities (
    roomamenities character varying NOT NULL,
    description character varying,
    createddate timestamp without time zone DEFAULT (now())::timestamp without time zone NOT NULL,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL
);


--
-- Name: setuproomamenities_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setuproomamenities ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setuproomamenities_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setuproomtariff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setuproomtariff (
    roomtypes character varying,
    ratetypes character varying,
    bussinesssource character varying,
    seasontype character varying,
    custcode character varying,
    tariff money,
    extraadult money,
    extrachild money,
    usetax smallint,
    active smallint,
    createddate timestamp without time zone DEFAULT (now())::timestamp without time zone NOT NULL,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL,
    floortype character varying,
    noroom character varying,
    startdate timestamp without time zone
);


--
-- Name: setuproomtariff_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setuproomtariff ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setuproomtariff_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setuproomtypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setuproomtypes (
    roomtypes character varying NOT NULL,
    keterangan character varying,
    recid bigint NOT NULL,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    adultmax integer,
    childmax integer,
    overbooking numeric,
    defaultrate numeric,
    defaultadultrate numeric,
    defaultchildrate numeric,
    baseadult integer,
    basechild integer
);


--
-- Name: setuproomtypes_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setuproomtypes ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setuproomtypes_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupseasontype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupseasontype (
    seasontype character varying NOT NULL,
    description character varying,
    fromday integer,
    frommonth integer,
    today integer,
    tomonth integer,
    yearperiod integer,
    active smallint,
    recid bigint NOT NULL,
    createddate timestamp without time zone DEFAULT (now())::timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying
);


--
-- Name: setupseasontype_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupseasontype ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupseasontype_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setupsubdevice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setupsubdevice (
    subdeviceid character varying NOT NULL,
    description character varying,
    createddate date,
    createdtime timestamp without time zone,
    createdby character varying,
    recid bigint NOT NULL,
    deviceid character varying,
    updatedatetime timestamp without time zone,
    updatedby character varying
);


--
-- Name: setupsubdevice_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setupsubdevice ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setupsubdevice_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setuptax; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setuptax (
    startdate timestamp without time zone NOT NULL,
    fromamount money,
    toamount money,
    tax1 numeric,
    tax2 numeric,
    tax3 numeric,
    tax4 numeric,
    tax1amount money,
    tax2amount money,
    tax3amount money,
    tax4amount money,
    createddate timestamp without time zone DEFAULT (now())::timestamp without time zone NOT NULL,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    recid bigint NOT NULL
);


--
-- Name: setuptax_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.setuptax ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.setuptax_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sysreportrunner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sysreportrunner (
    reportname character varying,
    rptcriteria character varying,
    rptparameter character varying,
    reporttitle character varying,
    recid bigint NOT NULL,
    createddate timestamp without time zone DEFAULT now()
);


--
-- Name: sysreportrunner_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sysreportrunner ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sysreportrunner_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: syssession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.syssession (
    sessionid character varying,
    username character varying,
    logindatetime timestamp without time zone
);


--
-- Name: sysuser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sysuser (
    username character varying,
    email character varying,
    password character varying,
    createddatetime timestamp without time zone,
    lastlogindatetime timestamp without time zone,
    fullname character varying,
    picprofile bytea,
    usergroupid character varying DEFAULT 'USER'::character varying,
    opencashier integer DEFAULT 0 NOT NULL
);


--
-- Name: transaksidetailhotspot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaksidetailhotspot (
    noroom character varying,
    ssid character varying,
    username character varying,
    password character varying,
    checkin timestamp without time zone,
    checkout timestamp without time zone,
    createddate timestamp without time zone DEFAULT now(),
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying,
    status smallint DEFAULT 0,
    reftransid character varying,
    recid bigint NOT NULL
);


--
-- Name: transaksidetailhotspot_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.transaksidetailhotspot ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transaksidetailhotspot_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transaksiroom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaksiroom (
    noroom character varying NOT NULL,
    refrecidroom bigint,
    arrival timestamp without time zone,
    recid bigint NOT NULL,
    createddatetime timestamp without time zone,
    createdby character varying,
    updatedatetime timestamp without time zone,
    updatedby character varying,
    jumlahadult integer,
    status smallint,
    departure timestamp without time zone,
    transaksiid character varying NOT NULL,
    keterangantambahan character varying,
    custcode character varying,
    refbookingcode character varying,
    actualcheckin timestamp without time zone,
    actualcheckout timestamp without time zone,
    checkoutby character varying,
    seasontype character varying,
    ratetype character varying,
    usetax1 smallint,
    usetax2 smallint,
    usetax3 smallint,
    usetax4 smallint,
    totalcharges money,
    discount money,
    totaltax money,
    total money,
    flatdiscount money,
    amountpaid money,
    deposit money,
    roundoff money,
    balance money,
    extracharges money,
    totalrate money,
    jumlahchild integer,
    paymenttype character varying,
    manualcheckin smallint DEFAULT 0,
    tipetrans character varying,
    settlepaydeposit money DEFAULT 0,
    closebalance money DEFAULT 0,
    closedate timestamp without time zone,
    closeby character varying,
    exportstatus smallint DEFAULT 0,
    journalidax character varying,
    settletxt character varying,
    bookingsource character varying
);


--
-- Name: transaksiroom_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.transaksiroom ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transaksiroom_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transaksiroomratedetail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaksiroomratedetail (
    transaksiid character varying,
    tanggal timestamp without time zone,
    totalcharges money,
    discount money,
    totaltax money,
    total money,
    ratetypes character varying,
    seasontype character varying,
    extraadult money,
    extrachild money,
    recid bigint NOT NULL,
    createddate timestamp without time zone,
    createdby character varying,
    updateddate timestamp without time zone,
    updatedby character varying
);


--
-- Name: transaksiroomratedetail_recid_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.transaksiroomratedetail ALTER COLUMN recid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transaksiroomratedetail_recid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vwdailyreport; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwdailyreport AS
 SELECT 'daily'::text AS period,
    (t3.departure)::date AS tanggal,
    COALESCE(t3.status, (- (1)::smallint)) AS status,
    t3.tipetrans,
    count(t3.*) AS roomssolddaily,
    avg((t3.totalrate)::numeric) AS arrdaily,
    sum((t3.totalrate)::numeric) AS roomrevenuedaily,
    ( SELECT count(*) AS count
           FROM public.setuproom
          WHERE (setuproom.active = 1)) AS totalroom
   FROM public.transaksiroom t3
  GROUP BY ((t3.departure)::date), t3.tipetrans, COALESCE(t3.status, (- (1)::smallint));


--
-- Name: vwdeviceid; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwdeviceid AS
 SELECT s.deviceid AS "Nomor Device Id",
    s.description AS keterangan,
    s.createddate,
    s.createdtime,
    s.createdby,
    s.ipaddress,
    s.ipport,
    s.updatedatetime,
    s.updatedby,
    s.recid
   FROM public.setupdevice s;


--
-- Name: vwoutlet; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwoutlet AS
 SELECT s.outletno,
    s.deviceid,
    s.subdeviceid,
    s.description,
    s.createddate,
    s.createdtime,
    s.createdby,
    s2.ipaddress,
    s2.ipport,
    s.updatedatetime,
    s.updatedby,
    s.recid,
    s3.description AS descriptionsubdevice
   FROM ((public.setupoutlet s
     LEFT JOIN public.setupdevice s2 ON (((s2.deviceid)::text = (s.deviceid)::text)))
     LEFT JOIN public.setupsubdevice s3 ON (((s3.subdeviceid)::text = (s.subdeviceid)::text)));


--
-- Name: vwroom; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwroom AS
 SELECT s2.outletno,
    s2.noroom,
    s2.description,
    s.deviceid,
    s.subdeviceid,
    s2.description AS descriptionoutlet,
    s2.createddatetime,
    s2.createdby,
    s.ipaddress,
    s.ipport,
    s2.updateddatetime,
    s2.updatedby,
    s2.recid,
    s.recid AS recidoutlet,
    s2.numbersequencetrans,
    s2.roomrate,
    s2.active,
    s2.statushousekeeping,
    s2.statusmaintenance,
    s2.statusroom,
    t3.custcode,
    t4.firstname,
    t4.lastname,
    t3.arrival,
    t3.departure,
    s2.floortype,
    s2.allowsmoking
   FROM (((public.setuproom s2
     LEFT JOIN public.vwoutlet s ON ((((s2.outletno)::text = (s.outletno)::text) AND ((s.recid)::integer = (s2.refrecidoutlet)::integer))))
     LEFT JOIN public.transaksiroom t3 ON ((((t3.noroom)::text = (s2.noroom)::text) AND ((t3.status)::integer = 0))))
     LEFT JOIN public.setupguestlist t4 ON (((t4.custcode)::text = (t3.custcode)::text)));


--
-- Name: vwlogdaily; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwlogdaily AS
 SELECT t2.noroom,
    t2.description,
    (t1.datetime)::date AS "Log Date",
    sum(t1.current) AS "Total Current (A)",
    avg(t1.voltage) AS "AVG voltage (V)",
    sum(t1.realpower) AS "Total Real Power (W)",
    sum(t1.reactivepower) AS "Total Reactivepower (W)",
    sum(t1.apparentpower) AS "Total Apparentpower (W)",
    (sum(t1.apparentpower) / (1000)::numeric) AS "Kilowatt hour (kWh)",
    ((sum(t1.apparentpower) / (1000)::numeric) * 1444.70) AS "Rupiah"
   FROM (public.logdaily t1
     LEFT JOIN public.vwroom t2 ON ((((t2.deviceid)::text = (t1.deviceid)::text) AND ((t2.subdeviceid)::text = (t1.subdeviceid)::text) AND ((t2.outletno)::text = (t1.outletno)::text))))
  GROUP BY t2.noroom, t2.description, ((t1.datetime)::date);


--
-- Name: vwlogdailydetail; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwlogdailydetail AS
 SELECT t2.noroom,
    t2.description,
    t1.datetime,
    t1.outletno,
    t1.current,
    t1.voltage,
    t1.realpower,
    t1.reactivepower,
    t1.apparentpower,
    t1."5minpowerconsumption",
    t1.recid,
    t1.deviceid,
    t1.subdeviceid,
    t1.createdby,
    ((t1.apparentpower / (5)::numeric) / (1000)::numeric) AS "KWH"
   FROM (public.logdaily t1
     LEFT JOIN public.vwroom t2 ON ((((t2.deviceid)::text = (t1.deviceid)::text) AND ((t2.subdeviceid)::text = (t1.subdeviceid)::text) AND ((t2.outletno)::text = (t1.outletno)::text))));


--
-- Name: vwsubdeviceid; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vwsubdeviceid AS
 SELECT s.subdeviceid AS "Nomor Sub Device Id",
    s.description AS keterangan,
    s2.deviceid AS "Nomor Device Id",
    s2.description AS "Keterangan Device Id",
    s.createddate,
    s.createdtime,
    s.createdby,
    s2.ipaddress,
    s2.ipport,
    s.recid,
    s.updatedatetime,
    s.updatedby
   FROM (public.setupsubdevice s
     LEFT JOIN public.setupdevice s2 ON (((s2.deviceid)::text = (s.deviceid)::text)));


--
-- Data for Name: cashiertrans; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3640.dat

--
-- Data for Name: housekeepingroom; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3636.dat

--
-- Data for Name: jumlahdata; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3644.dat

--
-- Data for Name: logdaily; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3610.dat

--
-- Data for Name: maintenancetype; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3650.dat

--
-- Data for Name: maitenanceroom; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3638.dat

--
-- Data for Name: setupbusinesssources; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3622.dat

--
-- Data for Name: setupdevice; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3602.dat

--
-- Data for Name: setupfloor; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3632.dat

--
-- Data for Name: setupguestlist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3618.dat

--
-- Data for Name: setupoutlet; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3606.dat

--
-- Data for Name: setuppaymenttype; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3643.dat

--
-- Data for Name: setupratetype; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3619.dat

--
-- Data for Name: setuproom; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3612.dat

--
-- Data for Name: setuproomamenities; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3626.dat

--
-- Data for Name: setuproomtariff; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3630.dat

--
-- Data for Name: setuproomtypes; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3616.dat

--
-- Data for Name: setupseasontype; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3624.dat

--
-- Data for Name: setupsubdevice; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3604.dat

--
-- Data for Name: setuptax; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3628.dat

--
-- Data for Name: sysreportrunner; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3648.dat

--
-- Data for Name: syssession; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3609.dat

--
-- Data for Name: sysuser; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3608.dat

--
-- Data for Name: transaksidetailhotspot; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3646.dat

--
-- Data for Name: transaksiroom; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3614.dat

--
-- Data for Name: transaksiroomratedetail; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3634.dat

--
-- Name: cashiertrans_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cashiertrans_recid_seq', 10, true);


--
-- Name: housekeepingroom_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.housekeepingroom_recid_seq', 44, true);


--
-- Name: logdaily_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logdaily_recid_seq', 9541, true);


--
-- Name: maintenancetype_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenancetype_recid_seq', 4, true);


--
-- Name: maitenanceroom_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maitenanceroom_recid_seq', 14, true);


--
-- Name: setupbusinesssources_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupbusinesssources_recid_seq', 7, true);


--
-- Name: setupdevice_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupdevice_recid_seq', 27, true);


--
-- Name: setupfloor_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupfloor_recid_seq', 7, true);


--
-- Name: setupguestlist_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupguestlist_recid_seq', 24, true);


--
-- Name: setupoutlet_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupoutlet_recid_seq', 7, true);


--
-- Name: setuppaymenttype_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setuppaymenttype_recid_seq', 4, true);


--
-- Name: setupratetype_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupratetype_recid_seq', 14, true);


--
-- Name: setuproom_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setuproom_recid_seq', 29, true);


--
-- Name: setuproomamenities_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setuproomamenities_recid_seq', 9, true);


--
-- Name: setuproomtariff_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setuproomtariff_recid_seq', 13, true);


--
-- Name: setuproomtypes_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setuproomtypes_recid_seq', 6, true);


--
-- Name: setupseasontype_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupseasontype_recid_seq', 3, true);


--
-- Name: setupsubdevice_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setupsubdevice_recid_seq', 10, true);


--
-- Name: setuptax_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setuptax_recid_seq', 2, true);


--
-- Name: sysreportrunner_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sysreportrunner_recid_seq', 108, true);


--
-- Name: transaksidetailhotspot_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transaksidetailhotspot_recid_seq', 23, true);


--
-- Name: transaksiroom_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transaksiroom_recid_seq', 84, true);


--
-- Name: transaksiroomratedetail_recid_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transaksiroomratedetail_recid_seq', 65, true);


--
-- Name: cashiertrans cashiertrans_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashiertrans
    ADD CONSTRAINT cashiertrans_pk PRIMARY KEY (recid);


--
-- Name: housekeepingroom housekeepingroom_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.housekeepingroom
    ADD CONSTRAINT housekeepingroom_pk PRIMARY KEY (recid);


--
-- Name: logdaily logdaily_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logdaily
    ADD CONSTRAINT logdaily_pk PRIMARY KEY (recid);


--
-- Name: maintenancetype maintenancetype_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenancetype
    ADD CONSTRAINT maintenancetype_pk PRIMARY KEY (recid);


--
-- Name: maitenanceroom maitenanceroom_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maitenanceroom
    ADD CONSTRAINT maitenanceroom_pk PRIMARY KEY (recid);


--
-- Name: setupguestlist mastercustomer_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupguestlist
    ADD CONSTRAINT mastercustomer_pk PRIMARY KEY (custcode);


--
-- Name: setupbusinesssources setupbusinesssources_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupbusinesssources
    ADD CONSTRAINT setupbusinesssources_pk PRIMARY KEY (companyname);


--
-- Name: setupdevice setupdevice_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupdevice
    ADD CONSTRAINT setupdevice_pk PRIMARY KEY (deviceid, recid);


--
-- Name: setupfloor setupfloor_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupfloor
    ADD CONSTRAINT setupfloor_pk PRIMARY KEY (floortype);


--
-- Name: setupfloor setupfloor_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupfloor
    ADD CONSTRAINT setupfloor_unique UNIQUE (recid);


--
-- Name: setupoutlet setupoutlet_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupoutlet
    ADD CONSTRAINT setupoutlet_pk PRIMARY KEY (outletno, recid, subdeviceid, deviceid);


--
-- Name: setuppaymenttype setuppaymenttype_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuppaymenttype
    ADD CONSTRAINT setuppaymenttype_pk PRIMARY KEY (recid);


--
-- Name: setupratetype setupratetype_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupratetype
    ADD CONSTRAINT setupratetype_pk PRIMARY KEY (ratetype);


--
-- Name: setuproom setuproom_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuproom
    ADD CONSTRAINT setuproom_pk PRIMARY KEY (recid);


--
-- Name: setuproomamenities setuproomamenities_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuproomamenities
    ADD CONSTRAINT setuproomamenities_pk PRIMARY KEY (roomamenities);


--
-- Name: setuproomtariff setuproomtariff_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuproomtariff
    ADD CONSTRAINT setuproomtariff_unique UNIQUE (recid);


--
-- Name: setuproomtypes setuproomtypes_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuproomtypes
    ADD CONSTRAINT setuproomtypes_pk PRIMARY KEY (roomtypes);


--
-- Name: setupseasontype setupseasontype_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupseasontype
    ADD CONSTRAINT setupseasontype_pk PRIMARY KEY (seasontype);


--
-- Name: setupseasontype setupseasontype_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupseasontype
    ADD CONSTRAINT setupseasontype_unique UNIQUE (recid);


--
-- Name: setupsubdevice setupsubdevice_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setupsubdevice
    ADD CONSTRAINT setupsubdevice_pk PRIMARY KEY (subdeviceid, recid);


--
-- Name: setuptax setuptax_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuptax
    ADD CONSTRAINT setuptax_pk PRIMARY KEY (startdate);


--
-- Name: setuptax setuptax_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setuptax
    ADD CONSTRAINT setuptax_unique UNIQUE (recid);


--
-- Name: sysreportrunner sysreportrunner_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sysreportrunner
    ADD CONSTRAINT sysreportrunner_pk PRIMARY KEY (recid);


--
-- Name: transaksidetailhotspot transaksidetailhotspot_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaksidetailhotspot
    ADD CONSTRAINT transaksidetailhotspot_pk PRIMARY KEY (recid);


--
-- Name: transaksiroom transaksiroom_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaksiroom
    ADD CONSTRAINT transaksiroom_unique UNIQUE (transaksiid);


--
-- Name: transaksiroomratedetail transaksiroomratedetail_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaksiroomratedetail
    ADD CONSTRAINT transaksiroomratedetail_pk PRIMARY KEY (recid);


--
-- Name: housekeepingroom_transid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX housekeepingroom_transid_idx ON public.housekeepingroom USING btree (transid);


--
-- Name: maitenanceroom_transid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maitenanceroom_transid_idx ON public.maitenanceroom USING btree (transid);


--
-- Name: setuproom_noroom_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX setuproom_noroom_idx ON public.setuproom USING btree (noroom);


--
-- Name: setuproomtariff_roomtypes_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX setuproomtariff_roomtypes_idx ON public.setuproomtariff USING btree (roomtypes, ratetypes, bussinesssource, seasontype, custcode, active, startdate);


--
-- Name: sysuser_username_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sysuser_username_idx ON public.sysuser USING btree (username);


--
-- Name: setupfloor floor_changes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER floor_changes BEFORE UPDATE ON public.setupfloor FOR EACH ROW EXECUTE FUNCTION public.floortype_changed();


--
-- Name: setuproomtypes roomtypes_changes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER roomtypes_changes BEFORE UPDATE ON public.setuproomtypes FOR EACH ROW EXECUTE FUNCTION public.roomtypes_changes();


--
-- PostgreSQL database dump complete
--

